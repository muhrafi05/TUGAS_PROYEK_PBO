import java.util.ArrayList;


abstract class Komponen {
    private String nama;
    private double harga;
    private int powerDraw; // Daya listrik yang dibutuhkan (Watt)

    public Komponen(String nama, double harga, int powerDraw) {
        this.nama = nama;
        this.harga = harga;
        this.powerDraw = powerDraw;
    }


    public String getNama() { return nama; }
    public double getHarga() { return harga; }
    public int getPowerDraw() { return powerDraw; }


    public abstract void tampilkanInfo();
}


class Processor extends Komponen {
    private String socketType;

    public Processor(String nama, double harga, int powerDraw, String socketType) {
        super(nama, harga, powerDraw); // Panggil konstruktor induk
        this.socketType = socketType;
    }

    public String getSocketType() { return socketType; }

    @Override
    public void tampilkanInfo() {
        System.out.println("[CPU]  " + getNama() + " (Socket: " + socketType + ", " + getPowerDraw() + "W)");
    }
}


class Motherboard extends Komponen {
    private String socketSupport;

    public Motherboard(String nama, double harga, int powerDraw, String socketSupport) {
        super(nama, harga, powerDraw);
        this.socketSupport = socketSupport;
    }

    public String getSocketSupport() { return socketSupport; }

    @Override
    public void tampilkanInfo() {
        System.out.println("[MOBO] " + getNama() + " (Support: " + socketSupport + ", " + getPowerDraw() + "W)");
    }
}


class VGA extends Komponen {
    private int vram;

    public VGA(String nama, double harga, int powerDraw, int vram) {
        super(nama, harga, powerDraw);
        this.vram = vram;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("[VGA]  " + getNama() + " (VRAM: " + vram + "GB, " + getPowerDraw() + "W)");
    }
}


class PSU extends Komponen {
    private int kapasitasDaya; // Kapasitas maksimal (misal 550W)

    public PSU(String nama, double harga, int kapasitasDaya) {
        super(nama, harga, 0); // PSU sendiri tidak "memakan" daya, tapi "menyediakan"
        this.kapasitasDaya = kapasitasDaya;
    }

    public int getKapasitasDaya() { return kapasitasDaya; }

    @Override
    public void tampilkanInfo() {
        System.out.println("[PSU]  " + getNama() + " (Kapasitas Max: " + kapasitasDaya + "W)");
    }
}


public class Main {
    public static void main(String[] args) {

        Processor cpu = new Processor("Intel Core i5-12400F", 2500000, 65, "LGA1700");
        Motherboard mobo = new Motherboard("ASUS Prime H610M", 1400000, 30, "LGA1700");
        VGA vga = new VGA("NVIDIA RTX 3060", 5000000, 170, 12);


        PSU psu = new PSU("Corsair CV550", 750000, 550);


        ArrayList<Komponen> rakitan = new ArrayList<>();
        rakitan.add(cpu);
        rakitan.add(mobo);
        rakitan.add(vga);
        rakitan.add(psu);


        System.out.println("=== DAFTAR KOMPONEN ===");
        double totalHarga = 0;
        int totalWattDibutuhkan = 0;

        for (Komponen k : rakitan) {
            k.tampilkanInfo();
            totalHarga += k.getHarga();
            totalWattDibutuhkan += k.getPowerDraw();
        }

        System.out.println("---------------------------------");
        System.out.println("Total Estimasi Watt: " + totalWattDibutuhkan + " Watt");
        System.out.println("Kapasitas PSU: " + psu.getKapasitasDaya() + " Watt");
        System.out.println("---------------------------------");


        System.out.println("\n=== HASIL DIAGNOSA ===");
        boolean rakitanValid = true;


        if (!cpu.getSocketType().equals(mobo.getSocketSupport())) {
            System.out.println(" GAGAL: Socket tidak cocok! CPU " + cpu.getSocketType() + " tidak masuk ke Mobo " + mobo.getSocketSupport());
            rakitanValid = false;
        } else {
            System.out.println(" Socket CPU & Motherboard Cocok.");
        }


        if (totalWattDibutuhkan > psu.getKapasitasDaya()) {
            System.out.println(" BAHAYA: PSU tidak kuat! Sistem butuh " + totalWattDibutuhkan + "W, tapi PSU cuma " + psu.getKapasitasDaya() + "W.");
            System.out.println("   -> Komputer mungkin mati mendadak atau meledak.");
            rakitanValid = false;
        } else {
            int sisaDaya = psu.getKapasitasDaya() - totalWattDibutuhkan;
            System.out.println(" Daya Listrik Aman. (Sisa headroom: " + sisaDaya + "W)");
        }


        System.out.println("\n=== STATUS AKHIR ===");
        if (rakitanValid) {
            System.out.println(" KOMPUTER BERHASIL DIRAKIT! Total Biaya: Rp " + (long)totalHarga);
        } else {
            System.out.println(" PERAKITAN GAGAL. Silakan ganti komponen yang bermasalah.");
        }
    }
}