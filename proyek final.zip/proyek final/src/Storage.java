class Storage extends Komponen {
    private String type; // SSD atau HDD
    public Storage(String nama, double harga, int powerDraw, String type) {
        super(nama, harga, powerDraw);
        this.type = type;
    }
    @Override
    public String tampilkanInfo() {
        return "Disk : " + getNama() + " | Type: " + type;
    }
}