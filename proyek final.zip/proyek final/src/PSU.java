class PSU extends Komponen {
    private int kapasitasDaya;
    public PSU(String nama, double harga, int kapasitasDaya) {
        super(nama, harga, 0);
        this.kapasitasDaya = kapasitasDaya;
    }
    public int getKapasitasDaya() { return kapasitasDaya; }

    @Override
    public String tampilkanInfo() {
        return "PSU : " + getNama() + " | Max: " + kapasitasDaya + " W";
    }
}


