class Motherboard extends Komponen {
    private String socketSupport;

    public Motherboard(String nama, double harga, int powerDraw, String socketSupport) {
        super(nama, harga, powerDraw);
        this.socketSupport = socketSupport;
    }
    public String getSocketSupport() { return socketSupport; }

    @Override
    public String tampilkanInfo() {
        return "Mobo : " + getNama() + " | Support: " + socketSupport;
    }
}