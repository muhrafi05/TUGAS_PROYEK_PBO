import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class AplikasiRakitPC {
    private JPanel panelUtama;
    private JComboBox<Processor> comboCpu;
    private JComboBox<Motherboard> comboMobo;
    private JComboBox<VGA> comboVga;
    private JComboBox<RAM> comboRam;
    private JComboBox<Storage> comboStorage;
    private JComboBox<PSU> comboPsu;
    private JButton btnRakit;
    private JTextArea txtHasil;


    private ArrayList<Processor> listCpu = new ArrayList<>();
    private ArrayList<Motherboard> listMobo = new ArrayList<>();
    private ArrayList<VGA> listVga = new ArrayList<>();
    private ArrayList<RAM> listRam = new ArrayList<>();
    private ArrayList<Storage> listStorage = new ArrayList<>();
    private ArrayList<PSU> listPsu = new ArrayList<>();

    public AplikasiRakitPC() {
        isiStokToko();
        isiComboBox();
        btnRakit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                prosesRakit();
            }
        });
    }

    private void prosesRakit() {

        Processor cpu = (Processor) comboCpu.getSelectedItem();
        Motherboard mobo = (Motherboard) comboMobo.getSelectedItem();
        VGA vga = (VGA) comboVga.getSelectedItem();
        RAM ram = (RAM) comboRam.getSelectedItem();
        Storage storage = (Storage) comboStorage.getSelectedItem();
        PSU psu = (PSU) comboPsu.getSelectedItem();


        double totalHarga = cpu.getHarga() + mobo.getHarga() + vga.getHarga() + ram.getHarga() + storage.getHarga() + psu.getHarga();
        int totalWatt = cpu.getPowerDraw() + mobo.getPowerDraw() + vga.getPowerDraw() + ram.getPowerDraw() + storage.getPowerDraw();


        txtHasil.setText("");
        txtHasil.append("=== HASIL RAKITAN ===\n");
        txtHasil.append(cpu.tampilkanInfo() + "\n");
        txtHasil.append(mobo.tampilkanInfo() + "\n");
        txtHasil.append(vga.tampilkanInfo() + "\n");
        txtHasil.append(psu.tampilkanInfo() + "\n");
        txtHasil.append(ram.tampilkanInfo() + "\n");
        txtHasil.append(storage.tampilkanInfo() + "\n");

        txtHasil.append("----------------------------\n");
        txtHasil.append("Total Biaya   : Rp " + (long)totalHarga + "\n");
        txtHasil.append("Estimasi Daya : " + totalWatt + " Watt\n");
        txtHasil.append("Kapasitas PSU : " + psu.getKapasitasDaya() + " Watt\n");
        txtHasil.append("----------------------------\n");


        txtHasil.append("\n[ DIAGNOSA ]\n");
        boolean aman = true;


        if (!cpu.getSocketType().equals(mobo.getSocketSupport())) {
            txtHasil.append(" ERROR: Socket tidak cocok!\n");
            txtHasil.append("   CPU " + cpu.getSocketType() + " vs Mobo " + mobo.getSocketSupport() + "\n");
            aman = false;
        } else {
            txtHasil.append(" Socket CPU & Mobo cocok.\n");
        }


        if (totalWatt > psu.getKapasitasDaya()) {
            txtHasil.append(" ERROR: PSU Kurang Daya!\n");
            txtHasil.append("   Butuh " + totalWatt + "W, Cuma ada " + psu.getKapasitasDaya() + "W\n");
            aman = false;
        } else {
            txtHasil.append(" Daya Listrik aman.\n");
        }


        if (aman) {
            JOptionPane.showMessageDialog(panelUtama, "PC SIAP DIRAKIT!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(panelUtama, "Rakitan Bermasalah! Cek Diagnosa.", "Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void isiComboBox() {
        for (Processor p : listCpu) comboCpu.addItem(p);
        for (Motherboard m : listMobo) comboMobo.addItem(m);
        for (VGA v : listVga) comboVga.addItem(v);
        for (RAM r : listRam) comboRam.addItem(r);
        for (Storage s : listStorage) comboStorage.addItem(s);
        for (PSU p : listPsu) comboPsu.addItem(p);
    }


    private void isiStokToko() {
        isiDataCpu();
        isiDataMobo();
        isiDataVga();
        isiDataRam();
        isiDataStorage();
        isiDataPsu();
    }


    private void isiDataCpu() {

        listCpu.add(new Processor("Intel Core i3-12100F", 1400000, 58, "LGA1700"));
        listCpu.add(new Processor("Intel Core i5-12400F", 2300000, 65, "LGA1700"));
        listCpu.add(new Processor("Intel Core i5-13600K", 5200000, 125, "LGA1700"));
        listCpu.add(new Processor("Intel Core i7-14700K", 7500000, 253, "LGA1700"));
        listCpu.add(new Processor("Intel Core i9-14900KS", 12000000, 320, "LGA1700"));


        listCpu.add(new Processor("AMD Ryzen 5 5600", 1900000, 65, "AM4"));
        listCpu.add(new Processor("AMD Ryzen 7 5700X3D", 3500000, 105, "AM4"));


        listCpu.add(new Processor("AMD Ryzen 5 7600", 3500000, 65, "AM5"));
        listCpu.add(new Processor("AMD Ryzen 7 7800X3D", 6800000, 120, "AM5"));
    }


    private void isiDataMobo() {

        listMobo.add(new Motherboard("ASRock H610M-HVS", 1100000, 30, "LGA1700"));
        listMobo.add(new Motherboard("ASUS Prime B760M-A", 2400000, 45, "LGA1700"));
        listMobo.add(new Motherboard("MSI MAG Z790 Tomahawk", 5500000, 70, "LGA1700"));


        listMobo.add(new Motherboard("Gigabyte B450M DS3H", 1200000, 35, "AM4"));
        listMobo.add(new Motherboard("ASUS ROG Strix B550-F", 3100000, 50, "AM4"));


        listMobo.add(new Motherboard("MSI Pro B650M-A WiFi", 2900000, 60, "AM5"));
        listMobo.add(new Motherboard("Gigabyte X670 Aorus Elite", 5800000, 80, "AM5"));
    }


    private void isiDataVga() {

        listVga.add(new VGA("NVIDIA GTX 1650", 2100000, 75, 4));
        listVga.add(new VGA("NVIDIA RTX 3050", 3300000, 130, 8));
        listVga.add(new VGA("NVIDIA RTX 3060", 4800000, 170, 12));
        listVga.add(new VGA("NVIDIA RTX 4060", 5200000, 115, 8));
        listVga.add(new VGA("NVIDIA RTX 4070 Super", 11000000, 220, 12));
        listVga.add(new VGA("NVIDIA RTX 4090", 32000000, 450, 24));


        listVga.add(new VGA("AMD Radeon RX 6600", 3200000, 132, 8));
        listVga.add(new VGA("AMD Radeon RX 7800 XT", 9500000, 263, 16));
    }


    private void isiDataRam() {
        listRam.add(new RAM("Team Elite 8GB DDR4", 350000, 3, 8));
        listRam.add(new RAM("Kingston Fury 16GB (2x8) DDR4", 750000, 6, 16));
        listRam.add(new RAM("Corsair Vengeance 32GB (2x16) DDR5", 1800000, 10, 32));
        listRam.add(new RAM("G.Skill Trident Z5 64GB (2x32) DDR5", 3500000, 15, 64));
    }


    private void isiDataStorage() {
        listStorage.add(new Storage("SSD SATA Adata 240GB", 300000, 3, "SSD SATA"));
        listStorage.add(new Storage("SSD NVMe Kingston 500GB", 650000, 5, "SSD NVMe Gen3"));
        listStorage.add(new Storage("SSD NVMe Samsung 980 Pro 1TB", 1600000, 7, "SSD NVMe Gen4"));
        listStorage.add(new Storage("SSD NVMe WD Black 2TB", 2800000, 8, "SSD NVMe Gen4"));
        listStorage.add(new Storage("HDD Seagate Barracuda 2TB", 950000, 15, "HDD 7200RPM"));
    }


    private void isiDataPsu() {
        listPsu.add(new PSU("Fantech 400W (Office)", 350000, 400));
        listPsu.add(new PSU("Cooler Master MWE 550W Bronze", 750000, 550));
        listPsu.add(new PSU("Corsair CV650 Bronze", 950000, 650));
        listPsu.add(new PSU("MSI MAG A750GL Gold", 1600000, 750));
        listPsu.add(new PSU("Corsair RM850e Gold", 2100000, 850));
        listPsu.add(new PSU("ASUS ROG Thor 1000W Platinum", 4500000, 1000));
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Aplikasi Rakit PC");
        frame.setContentPane(new AplikasiRakitPC().panelUtama);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(600, 500); // Atur ukuran agar pas
        frame.setVisible(true);
    }
}