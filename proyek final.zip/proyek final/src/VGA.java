class VGA extends Komponen {
    private int vram;
    public VGA(String nama, double harga, int powerDraw, int vram) {
        super(nama, harga, powerDraw);
        this.vram = vram;
    }
    @Override
    public String tampilkanInfo() {
        return "VGA : " + getNama() + " | VRAM: " + vram + " GB";
    }
}