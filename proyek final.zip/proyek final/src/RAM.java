class RAM extends Komponen {
    private int sizeGB;
    public RAM(String nama, double harga, int powerDraw, int sizeGB) {
        super(nama, harga, powerDraw);
        this.sizeGB = sizeGB;
    }
    @Override
    public String tampilkanInfo() {
        return "RAM : " + getNama() + " | Size: " + sizeGB + " GB";
    }
}