abstract class Komponen {
    private String nama;
    private double harga;
    private int powerDraw; // Watt

    public Komponen(String nama, double harga, int powerDraw) {
        this.nama = nama;
        this.harga = harga;
        this.powerDraw = powerDraw;
    }

    public String getNama() { return nama; }
    public double getHarga() { return harga; }
    public int getPowerDraw() { return powerDraw; }

    public abstract String tampilkanInfo();
    @Override
    public String toString() {
        return getNama() + " (Rp " + (long)getHarga() + ")";
    }
}
