class Processor extends Komponen {
    private String socketType;

    public Processor(String nama, double harga, int powerDraw, String socketType) {
        super(nama, harga, powerDraw);
        this.socketType = socketType;
    }
    public String getSocketType() { return socketType; }

    @Override
    public String tampilkanInfo() {
        return "CPU : " + getNama() + " | Socket: " + socketType;
    }
}
